﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.pages.AddEditPage;
using WpfApp1.utilities.entities;

namespace WpfApp1.pages
{
    /// <summary>
    /// Логика взаимодействия для RequestPage.xaml
    /// </summary>
    public partial class RequestPage : Page
    {
        public RequestPage()
        {
            InitializeComponent();
            requestsGrid.ItemsSource = getRequests();
        }

        // метод поулчеиня запросов
        private static List<RequestGrid> getRequests()
        {
            List<RequestGrid> requests = new List<RequestGrid>();
            using (var context = new BdEntities())
            {
                foreach (var request in context.requests)
                {
                    RequestGrid requestGrid = new RequestGrid
                    {
                        id = request.id,
                        address = getAddressNameById(request.address_id),
                        housemate = getHousemateNameById(request.housemate_id),
                        description = request.description,
                        date = request.date.ToString(),
                        worker = getWorkerNameById(request.worker_id),
                        status = getRequestStatusNameById(request.request_id)
                    };

                    requests.Add(requestGrid);
                }
            }

            return requests;
        }


        // методы получения названия по айди

        private static string getAddressNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.addresses.First(ch => ch.id == id).street;
            }
        }

        private static string getHousemateNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.housemates.First(ch => ch.id == id).FIO;
            }
        }

        private static string getWorkerNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.workers.First(ch => ch.id == id).FIO;
            }
        }


        // методы получения названия по айди
        private static string getRequestStatusNameById(int? id)
        {
            using (var context = new BdEntities())
            {
                return context.request_types.First(ch => ch.id == id).name;
            }
        }

        // методы навигации
        private void Add_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(new AddEditRequest());
        }

        private void Edit_Click(object sender, RoutedEventArgs e)
        {
            if (requestsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите запрос!", "Изменение запроса");
                return;
            }
            else
            {
                RequestGrid requestGrid = requestsGrid.SelectedItem as RequestGrid;
                NavigationService.Navigate(new AddEditRequest(requestGrid.id));
            }
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            if (requestsGrid.SelectedItem == null)
            {
                MessageBox.Show("Выберите запрос!", "Удаление запроса");
                return;
            }
            else
            {
                RequestGrid requestGrid = requestsGrid.SelectedItem as RequestGrid;
                using (var context = new BdEntities())
                {
                    requests request = context.requests.First(ch => ch.id == requestGrid.id); 
                    context.requests.Remove(request);
                    context.SaveChanges();
                    requestsGrid.ItemsSource = getRequests();
                }
            }
        }
    }
}
